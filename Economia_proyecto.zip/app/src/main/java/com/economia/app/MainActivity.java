package com.economia.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<Sale> sales = new ArrayList<>();
    android.content.SharedPreferences prefs;
    String money(double n){ return String.format(Locale.US,"$ %.0f",n); }

    public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("economia",0); load(); build(); showHome();
    }
    TextView title(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(20); t.setTextColor(Color.rgb(23,32,51)); t.setPadding(8,18,8,10); t.setTypeface(null,1); return t; }
    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(14); t.setTextColor(Color.DKGRAY); t.setPadding(12,12,12,4); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(243,245,248));
        TextView h=new TextView(this); h.setText("Economía\nFinanzas de tu negocio de comida"); h.setTextColor(Color.WHITE); h.setTextSize(24); h.setPadding(18,24,18,24); h.setBackgroundColor(Color.rgb(17,24,39)); root.addView(h);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,0,12,80);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(Color.WHITE);
        Button a=btn("🏠 Inicio"), p=btn("🍔 Productos"), r=btn("📋 Historial");
        a.setOnClickListener(v->showHome()); p.setOnClickListener(v->showProducts()); r.setOnClickListener(v->showHistory());
        nav.addView(a,new LinearLayout.LayoutParams(0,65,1)); nav.addView(p,new LinearLayout.LayoutParams(0,65,1)); nav.addView(r,new LinearLayout.LayoutParams(0,65,1)); root.addView(nav);
        setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void showHome(){
        clear(); content.addView(title("Resumen"));
        double inc=0,cost=0; for(Sale s:sales){inc+=s.qty*s.price;cost+=s.qty*s.cost;}
        content.addView(label("INGRESO TOTAL: "+money(inc))); content.addView(label("COSTOS: "+money(cost))); content.addView(label("GANANCIA: "+money(inc-cost)));
        content.addView(title("Registrar venta"));
        Spinner sp=new Spinner(this); ArrayList<String> names=new ArrayList<>(); for(Product p:products)names.add(p.name+" — "+money(p.price));
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names)); content.addView(sp);
        EditText qty=new EditText(this); qty.setHint("Cantidad"); qty.setInputType(2); qty.setText("1"); content.addView(qty);
        Button save=btn("Registrar venta"); content.addView(save); save.setOnClickListener(v->{ if(products.size()==0){Toast.makeText(this,"Agrega primero un producto",Toast.LENGTH_SHORT).show();return;} int i=sp.getSelectedItemPosition(); int q=Integer.parseInt(qty.getText().toString()); Product x=products.get(i); sales.add(new Sale(x.name,q,x.price,x.cost,new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()))); persist(); showHome();});
        content.addView(title("Últimas ventas")); int start=Math.max(0,sales.size()-7); for(int i=sales.size()-1;i>=start;i--) content.addView(label(sales.get(i).line()));
    }
    void showProducts(){
        clear(); content.addView(title("Productos que vendo"));
        EditText n=new EditText(this);n.setHint("Nombre");content.addView(n); EditText pr=new EditText(this);pr.setHint("Precio de venta");pr.setInputType(2|8192);content.addView(pr);EditText co=new EditText(this);co.setHint("Costo por unidad");co.setInputType(2|8192);content.addView(co);
        Button add=btn("Guardar producto");content.addView(add);add.setOnClickListener(v->{products.add(new Product(n.getText().toString(),Double.parseDouble(pr.getText().toString()),Double.parseDouble(co.getText().toString())));persist();showProducts();});
        content.addView(title("Mis productos")); for(int i=0;i<products.size();i++){ final int k=i; Product p=products.get(i); LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.addView(label(p.name+"  | Venta "+money(p.price)+" | Costo "+money(p.cost)+" | Ganancia "+money(p.price-p.cost)));Button del=btn("Eliminar");row.addView(del);del.setOnClickListener(v->{products.remove(k);persist();showProducts();});content.addView(row);}
    }
    void showHistory(){clear();content.addView(title("Historial de ventas")); if(sales.size()==0)content.addView(label("No hay ventas registradas.")); for(int i=sales.size()-1;i>=0;i--)content.addView(label(sales.get(i).line()));}
    void persist(){StringBuilder p=new StringBuilder();for(Product x:products)p.append(x.name.replace("|"," ")).append("|").append(x.price).append("|").append(x.cost).append("\n");prefs.edit().putString("p",p.toString()).apply();StringBuilder s=new StringBuilder();for(Sale x:sales)s.append(x.product.replace("|"," ")).append("|").append(x.qty).append("|").append(x.price).append("|").append(x.cost).append("|").append(x.date).append("\n");prefs.edit().putString("s",s.toString()).apply();}
    void load(){try{for(String l:prefs.getString("p","").split("\n")){if(l.trim().isEmpty())continue;String[] a=l.split("\\|");products.add(new Product(a[0],Double.parseDouble(a[1]),Double.parseDouble(a[2])));}for(String l:prefs.getString("s","").split("\n")){if(l.trim().isEmpty())continue;String[] a=l.split("\\|");sales.add(new Sale(a[0],Integer.parseInt(a[1]),Double.parseDouble(a[2]),Double.parseDouble(a[3]),a[4]));}}catch(Exception e){}}
    static class Product{String name;double price,cost;Product(String n,double p,double c){name=n;price=p;cost=c;}}
    static class Sale{String product,date;int qty;double price,cost;Sale(String p,int q,double pr,double c,String d){product=p;qty=q;price=pr;cost=c;date=d;}String line(){return date+" — "+product+" x"+qty+" — Ingreso "+String.format(Locale.US,"$ %.0f",qty*price)+" — Costo "+String.format(Locale.US,"$ %.0f",qty*cost)+" — Ganancia "+String.format(Locale.US,"$ %.0f",qty*(price-cost));}}
}